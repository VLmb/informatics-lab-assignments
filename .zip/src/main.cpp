#include "Interface.h"

int main(){

    runUI();
}

//dynamicarray - удаление элемента на месте отсутствует
//dynamicArray.resize - убедиться, что там нет мусора +
//set - это изменить эл-нт по индексу, а добавление - отдельно
//удаления нигде нет
//assert_custom(arr.Get(0) == 1 && arr.Get(2) == 3 - сравнивать надо массивы целиком